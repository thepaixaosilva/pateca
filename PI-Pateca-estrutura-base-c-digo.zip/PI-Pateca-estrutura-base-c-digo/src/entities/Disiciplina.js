export default class Disciplina {
    constructor (codDisciplina, nome, semestre) {
        this.codDisciplina = codDisciplina
        this.nome = nome
        this.semestre = semestre
    }
}