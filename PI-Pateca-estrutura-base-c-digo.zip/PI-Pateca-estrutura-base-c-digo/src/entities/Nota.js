export default class Nota {
    constructor (cod, codAluno, codMateria, codGabarito, nota) {
        this.cod = cod
        this.codAluno = codAluno
        this.codMateria = codMateria
        this.codGabarito = codGabarito
        this.nota = nota
    }
}