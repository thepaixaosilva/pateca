comandos iniciais:
npm init -y
npm install nodemon --save-dev
npm install express --save